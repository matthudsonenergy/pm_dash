# 100x PM

Design a high-leverage AI operating model for project managers.

This skill helps ChatGPT decide which PM tasks should be automated, augmented with AI, or kept human-led. It is built for practical operating-model design, not generic productivity advice.

## What it does

- maps PM work into concrete tasks, decisions, and recurring artifacts
- classifies each task as automate, augment, or human-led
- recommends workflows with explicit human ownership and approval gates
- sequences rollout into low-risk, high-value phases
- pressure-tests proposals for common automation failure modes

## Best use cases

Use this skill when you want to:
- decide which PM tasks are safe to automate
- redesign PM workflows with AI support
- create a reusable PM operating model or decision matrix
- develop a phased rollout plan for AI-enabled PM work
- prepare an executive summary explaining what should remain human-led

## Included files

- `SKILL.md` - core skill instructions and invocation metadata
- `agents/openai.yaml` - interface metadata
- `references/pm-ai-operating-matrix.md` - default starter framework
- `references/output-modes.md` - reusable output patterns
- `references/guardrails.md` - anti-patterns and risk checks
- `references/example-scenarios.md` - common PM contexts and adaptations
- `assets/icon.svg` - skill icon

## Example prompts

- Design a PM AI operating model for a software delivery team with weekly sprint reviews and monthly steering updates.
- Which parts of RAID management should be automated, augmented, or kept human-led?
- Create a 30-day rollout plan for introducing AI into PM workflows without losing control of stakeholder messaging.
- Turn this PM role into an automate versus augment versus human-led task matrix.
- Pressure-test our proposed PM automation model and identify where it creates hidden ownership risk.

## Design principles

- Prefer trust and controllability over maximum automation.
- Keep judgment-heavy work human-led.
- Use AI to reduce coordination toil and improve operating cadence.
- Name approval gates and failure risks explicitly.
- Start with low-risk, high-frequency workflow improvements.
