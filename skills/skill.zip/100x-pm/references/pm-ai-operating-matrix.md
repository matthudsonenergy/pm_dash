# PM AI Operating Matrix

Use this as the default starter matrix for PM leverage work. Tailor it to the user's project environment.

| PM task | Category | Best use of AI / automation | Human role | Main risk | Recommended workflow |
|---|---|---|---|---|---|
| Meeting notes | Automate | Clean transcript, summarize, extract actions, owners, due dates | Spot-check for misses and sensitive phrasing | Wrong action capture | Record meeting -> AI summary and action draft -> PM review -> publish |
| Action tracker updates | Automate | Add actions to tracker, detect missing owners or dates, flag overdue items | Resolve ambiguities and assign final owners | False or duplicate tasks | Meeting output -> tracker sync -> PM exception review |
| Reminder nudges | Automate | Send reminders for due or overdue actions and upcoming reviews | Decide when to override or escalate | Notification fatigue | Daily rule-based reminders -> PM reviews escalations only |
| Weekly status first draft | Augment | Turn team inputs into draft status, milestone changes, and top risks | Decide narrative, priority, and escalation wording | Polished but misleading update | Structured inputs -> AI draft -> PM edits for message and accuracy |
| Executive summary | Augment | Compress project state into concise bullets and themes | Choose what leadership actually needs to see | Missing political or context nuance | Source data + decisions + risks -> AI draft -> PM sharpens recommendation |
| RAID log refresh | Augment | Extract candidate risks, issues, assumptions, and dependencies from notes and updates | Set severity, owner, mitigation, and escalation path | Noise treated as signal | AI suggests new or changed entries -> PM validates and ranks |
| Dependency tracking | Augment | Detect cross-workstream blockers, overdue predecessors, and likely impact | Decide which dependencies matter and who intervenes | Over-flagging weak dependencies | Pull schedule or tracker data -> AI flags exceptions -> PM resolves |
| Change request intake | Augment | Draft impact summary on scope, timeline, cost, and dependencies | Make recommendation and negotiate tradeoffs | Underestimating second-order impact | Intake form -> AI impact draft -> PM validates with leads |
| Schedule variance analysis | Augment | Compare versions, summarize slips, identify probable downstream effects | Decide recovery plan and whether to rebaseline | Shallow causal analysis | New schedule -> AI diff and impact summary -> PM reviews with owners |
| Cross-document consistency check | Augment | Compare deck, plan, memo, and tracker for mismatched dates, owners, or status | Decide source of truth and fix strategy | Chasing harmless inconsistencies | AI compare pass -> PM resolves material conflicts only |
| Steering committee prep | Augment | Draft agenda, talking points, decision list, and pre-read | Set strategy, sequencing, and stakeholder handling | Weak decision framing | Gather open items -> AI draft pack -> PM finalizes ask and flow |
| Budget commentary | Augment | Summarize budget deltas and variance drivers | Judge what to escalate and how to frame it | Financial oversimplification | Pull budget inputs -> AI narrative draft -> PM validates with owners |
| Resource planning | Keep human-led | AI can summarize capacity constraints and options | Negotiate commitments, sequence work, and make tradeoffs | Treating people like interchangeable units | AI surfaces options -> PM and leads decide |
| Escalation decisions | Keep human-led | AI can organize facts and timeline | Decide whether, when, and to whom to escalate | Poor timing or damaged trust | AI brief -> PM chooses action and message |
| Stakeholder conflict resolution | Keep human-led | AI can draft neutral summaries or options | Read the room, build alignment, and repair trust | Tone-deaf handling | PM uses AI only for prep, not for the actual conversation |
| Priority setting | Keep human-led | AI can list scenarios and impacts | Decide what moves, what slips, and what gets cut | False precision | AI frames options -> PM and leaders choose |
| Scope negotiation | Keep human-led | AI can draft alternatives and pros and cons | Negotiate acceptable scope and commitments | Hidden assumptions | AI prepares options -> PM works live with stakeholders |
| Leadership updates in sensitive situations | Keep human-led | AI can help structure facts | PM owns tone, timing, and implications | Credibility loss | PM drafts or heavily edits before sending |
| Project kickoff materials | Augment | Draft charter, roles, milestones, and governance from template | Tailor for context and alignment needs | Generic setup | Template + inputs -> AI draft -> PM customizes |
| Postmortem and lessons learned | Augment | Cluster themes, summarize timeline, and draft actions | Separate symptoms from root causes | Superficial lessons | Collect notes and incidents -> AI synthesis -> PM validates root causes |

## Fast decision rule

- Automate if the task is repetitive, structured, and low-risk.
- Augment if the task needs synthesis but can be safely reviewed.
- Keep human-led if trust, judgment, politics, or consequences are central.

## Highest-value starting points

1. meeting outputs
2. weekly status drafting
3. RAID extraction and cleanup
4. stale action reminders
5. cross-document consistency checks
6. executive pre-read drafting
