# Output Modes

Use these patterns to match the user's request shape.

## 1. Quick triage

Use when the user wants a fast answer such as:
- what should I automate first?
- where are the easiest wins?
- which PM tasks are safe for AI?

### Structure

# [Title]

## Objective

## Top opportunities
- [opportunity]
- [opportunity]
- [opportunity]

## Top risks
- [risk]
- [risk]
- [risk]

## First 3 wins
1. [change]
2. [change]
3. [change]

## 2. Task matrix

Use when the user wants a reusable operating model or decision matrix.

### Structure

# [Title]

## Objective

## Recommended operating model

## Task matrix
| PM task | category | best use of ai / automation | PM owner / approval gate | main risk | recommended workflow |
|---|---|---|---|---|---|

## Priority rollout

## Guardrails

## 3. Rollout plan

Use when the user asks how to implement the model.

### Structure

# [Title]

## Objective

## Current-state assumptions

## Phase 1
- [change]
- [change]

## Phase 2
- [change]
- [change]

## Phase 3
- [change]
- [change]

## Dependencies and enablers

## Success measures

## Guardrails

## 4. Executive summary

Use when the user needs leadership buy-in or a concise rationale.

### Structure

# [Title]

## Objective

## Why this matters

## Recommended changes

## Risk controls

## What remains human-led

## Pilot recommendation

## Selection guidance

- If the user asks "what should I automate?" start with **Quick triage**.
- If the user asks for a reusable framework, start with **Task matrix**.
- If the user asks how to implement or sequence changes, use **Rollout plan**.
- If the user asks for a leadership-ready version, use **Executive summary**.
- If the request spans multiple needs, combine **Task matrix** with **Priority rollout**.
