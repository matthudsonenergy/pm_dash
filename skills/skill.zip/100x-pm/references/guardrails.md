# Guardrails and Anti-Patterns

Use this file to pressure-test recommendations before finalizing them.

## Core guardrail

Do not optimize for maximum automation. Optimize for trust, clarity, controllability, and better project flow.

## Hard boundaries

Keep the PM in the final loop when the workflow affects:
- scope
- schedule commitments
- budget framing
- staffing or role commitments
- escalations
- sensitive executive messaging
- client or partner communications
- politically sensitive stakeholder situations

## Common anti-patterns

### Polished but inaccurate status
The draft sounds confident, but the underlying data is stale, incomplete, or wrong.

**Fix:** require a source check, explicit assumptions, and PM review before publishing.

### Hidden ownership transfer
The workflow suggests AI owns a task that should remain accountable to the PM.

**Fix:** name the human owner and approval gate in the operating model.

### Reminder spam
Automation increases noise and weakens trust.

**Fix:** recommend rule-based reminders with escalation thresholds and PM exception review.

### Dashboard theater
The proposal creates reports or dashboards without changing operating cadence or behavior.

**Fix:** tie outputs to named review forums, decision meetings, or action cadences.

### Tool sprawl
The recommendation requires too many systems, integrations, or bespoke automations.

**Fix:** prefer the smallest reliable workflow that solves the problem.

### False precision
The model implies certainty in prioritization, estimates, or tradeoff recommendations.

**Fix:** present scenarios, assumptions, and review points instead of fake certainty.

### Extra admin burden
The recommendation saves time on paper while adding data-entry or maintenance work.

**Fix:** compare workflow cost before and after; remove low-value steps.

## Final check

Before finalizing a recommendation, verify that it:
- reduces manual chasing
- keeps judgment-heavy work human-led
- names the approval point for augmented outputs
- is easy to pilot
- is easy to validate
- would still make sense if one automation step failed
