# Example Scenarios

Use these as starter patterns when the user gives limited context.

## 1. Software delivery PM

### Typical tasks
- sprint and release status
- risk and dependency tracking
- meeting summaries
- action follow-up
- cross-functional stakeholder updates

### Good starting split
- **Automate:** meeting cleanup, action extraction, reminder nudges, tracker hygiene
- **Augment:** weekly status drafts, RAID refresh, dependency exception summaries, release-readiness summaries
- **Keep human-led:** prioritization, escalation wording, scope tradeoffs, stakeholder conflict handling

## 2. PMO or transformation office

### Typical tasks
- portfolio reporting
- steering committee prep
- milestone governance
- cross-project dependency tracking
- executive summaries

### Good starting split
- **Automate:** recurring data collection, formatting, stale-item detection, pre-read assembly
- **Augment:** portfolio status synthesis, variance summaries, cross-project dependency flags, draft executive narratives
- **Keep human-led:** executive escalation, portfolio tradeoffs, governance decisions, sensitive leadership messaging

## 3. Client delivery PM

### Typical tasks
- status reporting
- action and issue tracking
- RAID updates
- change request coordination
- client meeting preparation

### Good starting split
- **Automate:** meeting summaries, action extraction, deadline reminders, template-based report assembly
- **Augment:** change-impact drafts, client status first drafts, issue summaries, decision logs
- **Keep human-led:** client negotiation, scope changes, sensitive delivery messaging, escalation timing

## 4. Construction or field program PM

### Typical tasks
- daily or weekly field updates
- issue and safety logs
- schedule coordination
- subcontractor dependencies
- owner reporting

### Good starting split
- **Automate:** field-note cleanup, log formatting, due-date reminders, photo or note indexing when supported
- **Augment:** schedule variance summaries, issue clustering, owner update drafts, handoff summaries
- **Keep human-led:** site decisions, contractual commitments, stakeholder escalation, safety-critical judgment

## Adaptation guidance

When using these scenarios:
- keep the examples as a starting point, not a fixed answer
- adapt the matrix to the user's environment and risk level
- name which parts of the starter pattern you changed and why when that helps clarity
