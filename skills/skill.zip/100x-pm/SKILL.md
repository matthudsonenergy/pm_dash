---
name: 100x-pm
description: build a high-leverage ai operating model for project managers. use when the user wants to decide which pm tasks to automate, augment, or keep human-led; redesign pm workflows with ai and automation; create a reusable pm operating model, decision matrix, checklist, or rollout plan; pressure-test a proposed pm automation approach; or translate project, program, pmo, delivery, or transformation work into a practical 10x or 100x leverage system with clear human ownership and guardrails.
---

Turn project-management work into a higher-leverage operating model.

Treat "100x" as systems leverage, not individual heroics. Optimize for reliable project flow with less chasing, fewer surprises, clearer ownership, and faster decisions.

## Core operating principle

Separate PM work into three buckets:

- **Automate** for repetitive, structured, low-risk work that is easy to validate.
- **Augment** for drafting, synthesis, pattern detection, and structured analysis that still requires PM review before action.
- **Keep human-led** for work that depends on trust, judgment, tradeoffs, negotiation, politics, accountability, or external commitments.

Do not optimize for maximum automation. Optimize for adoption, trust, and better operating cadence.

## Inputs to infer or gather

Identify as many of these as the conversation supports:

- project, program, PMO, or transformation context
- delivery environment and tool stack
- current PM responsibilities and recurring ceremonies
- recurring deliverables and operating cadence
- stakeholder groups and decision forums
- current pain points, bottlenecks, and repeated failure modes
- sensitivity level of communications or decisions
- whether the user wants triage, a matrix, workflow, plan, policy, checklist, roadmap, or leadership-ready summary

If details are missing, proceed with grounded defaults rather than blocking. State key assumptions briefly.

## Workflow

1. **Map the work**
   - Break the PM scope into concrete tasks, ceremonies, decisions, and artifacts.
   - Normalize vague requests into task categories such as meeting output, status reporting, RAID management, dependency tracking, executive prep, escalation, scope negotiation, stakeholder management, change control, and tracker hygiene.

2. **Split mixed tasks into sub-steps**
   - Do not force a single label on an end-to-end workflow when only part of it should be automated.
   - Example: status reporting may be automated for collection, augmented for drafting, and human-led for final narrative and escalation wording.

3. **Classify each task**
   - Apply the classification test below.
   - When uncertain, bias toward augment instead of automate.

4. **Design the operating model**
   - For each task or sub-step, specify:
     - category: automate, augment, or human-led
     - what AI or automation should do
     - what the PM still owns
     - validation or approval gate
     - key failure risk
     - recommended workflow and cadence
   - Prefer simple systems that reduce friction over elaborate automations.

5. **Sequence implementation**
   - Prioritize low-risk, high-frequency tasks first.
   - Start with collection, formatting, reminders, tracker hygiene, and draft generation before sensitive stakeholder workflows.

6. **Pressure-test the design**
   - Check whether the proposal would create any of these failure modes:
     - polished but inaccurate status
     - reminder spam
     - hidden ownership confusion
     - over-automation of sensitive communication
     - dashboards without behavioral change
     - extra admin burden disguised as efficiency
   - Revise toward higher trust and easier adoption.

## Classification test

Apply this rule to each task.

### Automate
Choose this only when the task is:
- repeated often
- highly structured
- easy to validate
- low risk if slightly imperfect
- not creating sensitive external commitments

Typical examples:
- transcript cleanup
- action extraction
- tracker updates
- reminder nudges
- recurring formatting
- stale-item detection
- template-based document assembly

### Augment
Choose this when the task needs synthesis, comparison, prioritization support, or structured judgment, but still benefits from human review before action.

Typical examples:
- weekly status drafting
- executive summaries
- RAID refresh
- change-impact summaries
- schedule variance summaries
- steering committee prep
- cross-document consistency checks
- draft postmortem synthesis

### Keep human-led
Choose this when the task depends on judgment, trust, influence, negotiation, or consequence management.

Typical examples:
- prioritization
- escalation choices
- scope negotiation
- stakeholder conflict resolution
- leadership messaging in sensitive situations
- staffing tradeoffs
- major tradeoff decisions

## Tie-breaker rules

Use these hard boundaries when the classification is ambiguous:

- If the task changes scope, timeline, budget, staffing, commitments, or executive messaging, do not automate the final decision.
- If validation is difficult or subjective, do not automate.
- If the output will be sent to senior stakeholders, clients, regulators, or partners, keep the PM in the final review loop.
- If the workflow transfers accountability away from the PM without an explicit approval gate, redesign it.
- If the task is politically sensitive, use AI for prep only.
- When in doubt, classify as **augment** rather than **automate**.

## Output mode selection

Choose the output structure that best matches the request.

### Quick triage
Use for prompts like "what should I automate?" or "where are the easiest wins?"

Return:
- objective
- top opportunities
- top risks
- first 3 wins

### Task matrix
Use for prompts asking how to split work across automate, augment, and human-led.

Use a table with these columns:
- PM task
- category
- best use of ai / automation
- PM owner / approval gate
- main risk
- recommended workflow

### Rollout plan
Use for prompts about implementation.

Return:
- objective
- current-state assumptions
- phase 1, phase 2, phase 3 rollout
- dependencies and enablers
- success measures
- guardrails

### Executive summary
Use for leadership-facing requests.

Return:
- objective
- why this operating model matters
- recommended changes
- risk controls
- what remains human-led
- pilot recommendation

## Default output structure

Use this when the user does not specify a format.

# [Title]

## Objective
Briefly state what the PM is trying to achieve.

## Recommended operating model
Summarize how work should be split across automate, augment, and human-led.

## Task matrix
Use the columns defined above.

## Priority rollout
Recommend the first 3 to 6 changes to implement.

## Guardrails
List the main pitfalls to avoid.

## Assumptions
State only the assumptions that materially shaped the design.

## Sequencing defaults
Unless the user provides stronger constraints, recommend:

### Phase 1: low-risk workflow hygiene
1. meeting summary and action extraction
2. overdue action reminders
3. weekly status first draft
4. recurring formatting and tracker cleanup

### Phase 2: synthesis and control improvements
1. RAID candidate extraction
2. cross-document mismatch detection
3. dependency exception flagging
4. schedule variance summaries

### Phase 3: leadership and governance acceleration
1. executive pre-read drafting
2. steering committee prep
3. change-impact summarization
4. postmortem synthesis

## Response guidance

- Be concrete. Name specific PM tasks and workflows.
- Translate abstract leverage language into operating steps.
- Prefer simple implementations over tool sprawl.
- Distinguish between personal acceleration, workflow automation, team-scale systems, and org-scale leverage when useful.
- For sensitive stakeholder situations, explicitly keep the PM in the loop.
- Name the validation point, approval gate, or failure signal for any automation recommendation.
- When context is sparse, adapt the default starter framework instead of producing generic AI enthusiasm.

## Anti-patterns to avoid

Do not:
- recommend full automation for escalations, scope negotiation, stakeholder conflict resolution, or sensitive leadership messaging
- imply that AI owns delivery accountability
- recommend dashboards without an operating cadence and named owners
- recommend automation that increases admin burden more than it removes
- produce polished workflows that hide uncertainty, ownership, or risk
- present tool sprawl as strategy

## Quality bar

A strong result should:
- reduce manual chasing
- increase decision speed
- preserve PM ownership of judgment-heavy work
- name concrete risks of bad automation
- define clear human review points
- be pilotable in a short time horizon
- recommend workflows people are likely to trust and adopt

A weak result usually over-indexes on tools and under-specifies ownership, risk, validation, and operating cadence.

## Bundled references

Use these bundled references as needed:

- `references/pm-ai-operating-matrix.md` for the default starter framework
- `references/output-modes.md` for reusable output templates
- `references/guardrails.md` for anti-patterns and risk checks
- `references/example-scenarios.md` for common PM contexts and how to adapt the framework

Adapt the references to the user's context instead of reproducing them mechanically.
